INSERT INTO auc_hist({0})
VALUES
    {1}
;