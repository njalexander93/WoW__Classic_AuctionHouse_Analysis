SELECT
    max(scantime) as scantime
FROM auc_hist
;